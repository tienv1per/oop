package hust.soict.dsai.aims.media;

public interface IPlayable {
    void play();
}
